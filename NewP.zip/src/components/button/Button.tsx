import ButtonIcon from "./ButtonIcon";
import ButtonLogin from "./ButtonLogin";
import ButtonPrimary from "./ButtonPrimary";
import { ButtonUtil } from "./ButtonUtil";
const Button = () => {
    return <></>;
};

Button.Primary = ButtonPrimary;

Button.Icon = ButtonIcon;

Button.Login = ButtonLogin;

Button.Util = ButtonUtil;
export default Button;
