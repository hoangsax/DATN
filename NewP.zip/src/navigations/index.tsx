import { AuthNav } from '@/navigations/authStack'
import { BotNav } from './bottomNav';
export {AuthNav, BotNav};