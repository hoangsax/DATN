import themeReducer from './theme.slice'

export * from './theme.slice'

export default themeReducer;