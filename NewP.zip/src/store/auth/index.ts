import authReducer from './auth.slice'

export * from './auth.slice'

export default authReducer;