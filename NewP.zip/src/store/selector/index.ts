// // selectors.ts
// import { RootState } from '@/store'; // Adjust the path to your RootState file and store setup

// export const selectUser = (state: RootState) => state.auth.user;
// export const selectIsLoggedIn = (state: RootState) => state.auth.user !== null && state.auth.token !== null;
