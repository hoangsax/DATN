export const xml= `<svg width="70" height="87" viewBox="0 0 70 87" fill="none" xmlns="http://www.w3.org/2000/svg">
<g filter="url(#filter0_ddddd_4572_2994)">
<rect x="9" y="2.22223" width="52" height="52" rx="12" fill="#006EFF"/>
<path d="M29 29.7222C31.4853 29.7222 33.5 31.7369 33.5 34.2222C33.5 36.7075 31.4853 38.7222 29 38.7222C26.5147 38.7222 24.5 36.7075 24.5 34.2222C24.5 31.7369 26.5147 29.7222 29 29.7222Z" fill="#F9FBFF"/>
<path d="M27.5 26.7222L27.5 17.7222L29.5 17.7222L29.5 26.7222H27.5Z" fill="#F9FBFF"/>
<path d="M41 26.7222C38.5147 26.7222 36.5 24.7075 36.5 22.2222C36.5 19.7369 38.5147 17.7222 41 17.7222C43.4853 17.7222 45.5 19.7369 45.5 22.2222C45.5 24.7075 43.4853 26.7222 41 26.7222Z" fill="#F9FBFF"/>
<path d="M42.5 29.7222V38.7222H40.5L40.5 29.7222H42.5Z" fill="#F9FBFF"/>
</g>
<defs>
<filter id="filter0_ddddd_4572_2994" x="0" y="0.222229" width="70" height="86" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset/>
<feColorMatrix type="matrix" values="0 0 0 0 0.188235 0 0 0 0 0.552941 0 0 0 0 1 0 0 0 0.1 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_4572_2994"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="1"/>
<feGaussianBlur stdDeviation="1.5"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.188235 0 0 0 0 0.552941 0 0 0 0 1 0 0 0 0.1 0"/>
<feBlend mode="normal" in2="effect1_dropShadow_4572_2994" result="effect2_dropShadow_4572_2994"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="6"/>
<feGaussianBlur stdDeviation="3"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.188235 0 0 0 0 0.552941 0 0 0 0 1 0 0 0 0.09 0"/>
<feBlend mode="normal" in2="effect2_dropShadow_4572_2994" result="effect3_dropShadow_4572_2994"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="13"/>
<feGaussianBlur stdDeviation="4"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.188235 0 0 0 0 0.552941 0 0 0 0 1 0 0 0 0.05 0"/>
<feBlend mode="normal" in2="effect3_dropShadow_4572_2994" result="effect4_dropShadow_4572_2994"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="23"/>
<feGaussianBlur stdDeviation="4.5"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.188235 0 0 0 0 0.552941 0 0 0 0 1 0 0 0 0.01 0"/>
<feBlend mode="normal" in2="effect4_dropShadow_4572_2994" result="effect5_dropShadow_4572_2994"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect5_dropShadow_4572_2994" result="shape"/>
</filter>
</defs>
</svg>`
