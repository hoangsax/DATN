export const xml = `<svg width="18" height="22" viewBox="0 0 18 22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16.3278 15.0498V5.32134C16.3249 4.17616 15.8773 3.07869 15.083 2.26892C14.2886 1.45915 13.212 1.00293 12.0886 1H5.56689C4.44348 1.00293 3.36691 1.45915 2.57254 2.26892C1.77817 3.07869 1.33063 4.17616 1.32776 5.32134V21L8.58863 15.4598L16.2951 20.7451L16.3278 15.0498Z" stroke="#8895A7" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M9.32776 4H11.358C11.8804 4 12.3814 4.17216 12.7508 4.47861C13.1202 4.78507 13.3278 5.20071 13.3278 5.63409V8" stroke="#8895A7" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`
