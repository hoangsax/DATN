export const xml = `<svg width="17" height="23" viewBox="0 0 17 23" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16 15.5498V5.82134C15.9971 4.67616 15.5496 3.57869 14.7552 2.76892C13.9608 1.95915 12.8843 1.50293 11.7609 1.5H5.23913C4.11572 1.50293 3.03915 1.95915 2.24478 2.76892C1.45041 3.57869 1.00287 4.67616 1 5.82134V21.5L8.26087 15.9598L15.9674 21.2451L16 15.5498Z" fill="#3C94FF" stroke="#3C94FF" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M9 4.5H11.0302C11.5526 4.5 12.0537 4.67216 12.4231 4.97861C12.7925 5.28507 13 5.70071 13 6.13409V8.5" fill="#3C94FF"/>
<path d="M9 4.5H11.0302C11.5526 4.5 12.0537 4.67216 12.4231 4.97861C12.7925 5.28507 13 5.70071 13 6.13409V8.5" stroke="#F9FBFF" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`