export const stacks = {
    HOMESTACK: 'HomeStack',
    LOCATIONSTACK: 'LocationStack',
    BOOKMARKSTACK: 'BookmarkStack',
    PROFILESTACK: 'ProfileStack',
    MYTABS: 'MyTabs',
    LOGINSTACK: 'LoginStack',
    PROJECTSTACK: 'ProjectStack',
}