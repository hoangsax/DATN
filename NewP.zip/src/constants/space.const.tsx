import { horizontalScale } from "@/utils";

export const spaces = {
    contentPaddingHorizontal: horizontalScale(10),
    globalPadding: horizontalScale(15)
}