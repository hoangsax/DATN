export const weight = {
    normal: '400',
    semibold: '600',
    bold: '700',
    extrabold: '800',
    black: '900',
    thin: '100',
    light: '200',
}