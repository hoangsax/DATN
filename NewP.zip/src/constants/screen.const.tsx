export const screens = {
    HOME: 'Home',
    DETAILS: 'Details',
    SETTINGS: 'Settings',
    LOGIN: 'Login',
    REGISTER: 'Register',
    PROFILE: 'Profile',
    SEARCH: 'Search',
    ADD_PROPERTY: 'AddProperty',
    PROJECT: 'Project',
    REINFO: 'ReInfo',
    LEASE: 'Lease',
    INVEST: 'Invest'
}