export const images = {
    LOGO: require("@/assets/images/logo.png"),
    logo: require("@/assets/images/logo.png"),
    PROFILE: require("@/assets/images/psuedo_data/profile.png"),
    RECARD_DEFAULLT: require("@/assets/images/recard_default.jpg"),
    DEFIMG: require("@/assets/images/BACKGROUND.png")
}

export type ImageTypes = keyof typeof images;